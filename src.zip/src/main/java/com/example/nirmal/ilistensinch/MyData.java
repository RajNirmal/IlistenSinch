package com.example.nirmal.ilistensinch;



public class MyData {
//Home datas....
static String[] nick={"vijay","raja","vinoth","vignesh","nirmal","srini"};
    static String[] tit={"Title1","Title2","Title3","Title4","Title5","Title6"};
    static String[] cat={"catogery1","catogery2","catogery3","catogery4","catogery5","catogery6"};
    static String[] desc={"Description1","Description2","Description3","Description4","Description5","Description6"};
    static String[] dt={"Date&Time:sep8,5.30PM", "Date&Time:july29,9.00PM", "Date&Time:feb22,6.00AM", "Date&Time:may31,1.50PM", "Date&Time:may2,5.30PM", "Date&Time:aug15,10.15AM", "Date&Time:jab20,12.30PM"};
    static String[] stat={"Active","Deactive","Active","Deactive","Deactive","Active"};
    static String[] part={"NickName1,NickName2","NickName1,NickName2","NickName1,NickName2","NickName1,NickName2","NickName1,NickName2","NickName1,NickName2"};

    static String[] orderno = {"OrderNo:4478", "OrderNo:2456", "OrderNo:6589", "OrderNo:6521", "OrderNo:3647", "OrderNo:5647", "OrderNo:6398","OrderNo:5234", "OrderNo:1787", "OrderNo:3641", "OrderNo:3648"};
    static String[] date = {"Date:12-11-2016", "Date:14-01-2016", "Date:30-01-2016", "Date:02-12-2016", "Date:09-10-2016", "Date:16-01-2016", "Date:19-06-2016", "Date:23-05-2016", "Date:06-10-2016", "Date:08-12-2016","Date:23-08-2016"};
    static String[] cust = {"abc pvt. Ltd.", "cvf pvt. Ltd.", "ttr pvt. Ltd.", "ggt pvt. Ltd.", "dew pvt. Ltd.", "tde pvt. Ltd.", "mmj pvt. Ltd.","tgf pvt. Ltd.", "sic pvt. Ltd.", "cde pvt. Ltd.", "rde pvt. Ltd."};
    static String[] at = {"@", "@", "@", "@", "@", "@", "@","@", "@", "@", "@"};
    static String[] custname = {"karthick", "dinesh", "vignesh", "charan", "rajesh", "kumar", "aakash","ajay", "syed", "vinoth", "ram"};
    static String[] addr = {"chennai", "thiruvallur", "cuddalore", "kancheepuram", "kanyakumari", "pudukkottai", "dindigul","ooty", "chennai", "thiruvallur", "namakkal"};
    static String[] item = {" Rs 3458.32", " Rs 6584.78", " Rs 3568.22", " 6574.21", " Rs 5547.25", " Rs 4478.98", " Rs 3369.84"," Rs 6678.54", " Rs 9978.25", " Rs 5789.36", " Rs 9987.45"};
    static String[] status = {"Status:Done", "Status:Pending", "Status:Done", "Status:Pending", "Status:Pending", "Status:Done", "Status:Pending","Status:Pending", "Status:Pending", "Status:Done", "Status:Pending"};
}
